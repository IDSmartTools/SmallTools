1.关闭InDesign
2.解压压缩包
3.复制“win64 CC20XX”文件夹到“****\Adobe InDesign 20XX\Plug-Ins”
4.复制“xxxx.dll”到“****\Adobe InDesign 20XX”注意：不是复制文件夹，需要复制几个文件夹下的几个dll文件直接复制到\Adobe InDesign 20XX下，如果你搞不清楚，那么复制完文件夹，在复制那几个dll文件到\Adobe InDesign 20XX
5.启动InDesign


1. Turn off InDesign
2. Extract the archive
3. Copy "win64 CC20XX" folder to "****\Adobe InDesign 20XX\Plug-Ins"  Note: This is not about copying the entire folder. You need to directly copy several DLL files from a few folders into the \Adobe InDesign 20XX directory. If you're unsure, first copy the folders and then copy those specific DLL files into \Adobe InDesign 20XX.
4. Copy "xxxx.dll" to "****\Adobe InDesign 20XX"
5. Start InDesign